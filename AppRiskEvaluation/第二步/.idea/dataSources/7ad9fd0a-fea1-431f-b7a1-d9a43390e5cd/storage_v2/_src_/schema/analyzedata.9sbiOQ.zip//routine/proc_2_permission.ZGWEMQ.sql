create procedure Proc_2_permission()
  BEGIN

  DELETE
    FROM permission_temp;
  DELETE
    FROM permission_bianhao;
  DELETE
    FROM app_recommand;

  INSERT INTO permission_temp (topicid, id, permid, probability)
    SELECT
      a.topicid,
      a.id,
      b.permid,
      a.probability * b.probability
    FROM lda_topic a,
         topicid_permission b
    WHERE a.topicid = b.topicid
    AND a.probability * b.probability >= (SELECT
        p_value
      FROM d_param
      WHERE param_code = 'pro_threshold');

  INSERT INTO permission_bianhao (id, realper)
    SELECT DISTINCT
      id,
      ''
    FROM lda_topic
    ORDER BY id;

  UPDATE permission_bianhao b
  SET realper = (SELECT
      CONCAT('[', GROUP_CONCAT(DISTINCT a.permid ORDER BY a.probability DESC SEPARATOR ', '), ']')
    FROM permission_temp a
    WHERE a.id = b.id
    AND 1 = 1
    GROUP BY a.id);

  INSERT INTO app_recommand (id, permid, probability)
    SELECT
      id,
      permid,
      SUM(probability)
    FROM permission_temp
    GROUP BY id,
             permid;

  SET GLOBAL group_concat_max_len = 4294967295;

  UPDATE permission a
  SET lessper = (SELECT
      GROUP_CONCAT(CONCAT(SUBSTRING_INDEX(b.permission, '.', LENGTH(b.permission) - LENGTH(REPLACE(b.permission, '.', ''))), '.', UPPER(SUBSTRING_INDEX(b.permission, '.', -1))) ORDER BY probability DESC SEPARATOR ';')
    FROM permission_temp c,
         permissions b
    WHERE c.permid = b.permid
    AND a.id = c.id
    AND 1 = 1
    GROUP BY a.id);

  SET GLOBAL group_concat_max_len = 1024;

  COMMIT;

END;

