create procedure Proc_app_permission_list()
  BEGIN
  DECLARE my_id,
          rownum1 int;
  DECLARE my_realper,
          str1,
          str2 varchar(255);
  DECLARE done int DEFAULT FALSE;

  DECLARE perm_bianhao CURSOR FOR
  SELECT
    id,
    SUBSTR(realper FROM 2 FOR LENGTH(realper) - 2)
  FROM permission_bianhao0;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  DELETE
    FROM app_permission;
  DELETE
    FROM app_topicid_permission;
  DELETE
    FROM topicid_permission;
  DELETE
    FROM topicid_permission_temp;
  OPEN perm_bianhao;
myLoop:
  LOOP
    FETCH perm_bianhao INTO my_id, my_realper;
    IF done THEN
      LEAVE myLoop;
    END IF;
    IF LENGTH(TRIM(my_realper)) > 0 THEN
      SET rownum1 = f_ins_permission(my_id, my_realper);
    END IF;

  END LOOP myLoop;
  CLOSE perm_bianhao;


  INSERT INTO app_topicid_permission (topicid, id, permid, probability)
    SELECT
      a.topicid,
      a.id,
      b.permid,
      a.probability * b.probability
    FROM lda_topic0 a,
         app_permission b
    WHERE a.id = b.id;

  INSERT INTO topicid_permission_temp (topicid, permid, probability, rate, rownum)
    SELECT
      topicid,
      permid,
      0,
      SUM(probability),
      0
    FROM app_topicid_permission
    GROUP BY topicid,
             permid;


  UPDATE topicid_permission_temp a
  SET a.rownum = (SELECT
      counts
    FROM (SELECT
        topicid,
        COUNT(DISTINCT id) counts
      FROM app_topicid_permission
      GROUP BY topicid) b
    WHERE a.topicid = b.topicid);

  UPDATE topicid_permission_temp
  SET probability = rate / rownum
  WHERE 1 = 1;

  INSERT INTO topicid_permission (topicid, permid, probability)
    SELECT
      topicid,
      permid,
      rate / rownum
    FROM topicid_permission_temp a
    WHERE 20 >= (SELECT
        COUNT(*)
      FROM topicid_permission_temp b
      WHERE a.topicid = b.topicid
      AND a.probability <= b.probability)
    ORDER BY topicid, probability DESC;

  COMMIT;
END;

